# no-ui-slider

Usage
=====

importing nouislider.js
-----------------------
> import noUiSlider from 'no-ui-slider';

importing nouislider.css
------------------------

> import 'no-ui-slider/css/nouislider.css';
