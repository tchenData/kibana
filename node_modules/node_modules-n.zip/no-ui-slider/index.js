module.exports = require('./lib/nouislider');
