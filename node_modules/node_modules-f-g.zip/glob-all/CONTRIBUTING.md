* `npm install`
* `npm start`
* Edit `src/index.coffee`