=CHANGELOG

==v1.1.1

* Fixes random date functions that did not distribute results.
  - contributed by pmalouin
* Fixes context of findName
  - contributed by juampi92
* Updates to switch changes over to using 2 args to support min/max
  - contributed by avanderhoorn & edshadi
* Added ISO 3166 countries
  - contributed by MaerF0x0
* UMD support
  - contirbuted by xaka
* Uk Postal Codes
  - contributed by schmtw
* Undefined global object for webworker fix
  - contributed by dnbard