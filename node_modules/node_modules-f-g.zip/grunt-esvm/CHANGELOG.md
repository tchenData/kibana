# changelog

## v3.0.0
 - updated libesvm to 3.4.5
 - default config (read from esvm.options.config) is now deeply merged with each tasks' config. Use `null` to prevent a delete a value from the default config.
