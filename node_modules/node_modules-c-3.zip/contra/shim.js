require('./src/contra.shim.js');
