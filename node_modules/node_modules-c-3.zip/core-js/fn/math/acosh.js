require('../../modules/es6.math.acosh');
module.exports = require('../../modules/$.core').Math.acosh;