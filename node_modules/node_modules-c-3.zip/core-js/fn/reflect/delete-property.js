require('../../modules/es6.reflect.delete-property');
module.exports = require('../../modules/$.core').Reflect.deleteProperty;