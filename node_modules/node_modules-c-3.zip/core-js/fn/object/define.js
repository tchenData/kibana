require('../../modules/core.object.define');
module.exports = require('../../modules/$.core').Object.define;