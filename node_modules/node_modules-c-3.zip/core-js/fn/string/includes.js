require('../../modules/es6.string.includes');
module.exports = require('../../modules/$.core').String.includes;