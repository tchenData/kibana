require('../../modules/es6.array.fill');
module.exports = require('../../modules/$.core').Array.fill;