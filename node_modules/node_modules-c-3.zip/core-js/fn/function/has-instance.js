require('../../modules/es6.function.has-instance');
module.exports = Function[require('../../modules/$.wks')('hasInstance')];