require('../../modules/es6.number.parse-int');
module.exports = parseInt;