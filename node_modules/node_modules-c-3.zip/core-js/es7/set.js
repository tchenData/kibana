require('../modules/es7.set.to-json');
module.exports = require('../modules/$.core').Set;