# 1.0.1

* Fixes for plugin guidelines compatibility.

# 1.0.0

* Initial release.
