# 1.0.2

* Minor boost in performance with reduced stringify passes.

# 1.0.1

* Fixes an issue where duplicated keyframes with the same name would cause
  an infinite loop.

# 1.0.0

* Initial release.
