# 1.0.3

* Improved performance by reducing the amount of AST iterations.
* Converted the codebase to ES6.

# 1.0.2

* Fixes an integration issue where the module would crash on `undefined`
  `rule.nodes`.

# 1.0.1

* Fixes an issue where multiple animations were not being recognized.

# 1.0.0

* Initial release.
