# 1.1.1

* Fixes an issue where `flex` properties were being mangled by the module.

# 1.1.0

* Adds support for `flex-flow` (thanks to @yisibl).

# 1.0.1

* The module will now recognise `auto` as a valid value.

# 1.0.0

* Initial release.
