# 1.0.3

* Improved performance by iterating the AST less times.

# 1.0.2

* Fixes an issue where multiple, comma separated animations with insufficient
  whitespace were not being renamed.

# 1.0.1

* Documentation/metadata tweaks for plugin guidelines compatibility.

# 1.0.0

* Initial release.
