#pez

[![Current Version](https://img.shields.io/npm/v/pez.svg)](https://www.npmjs.org/package/pez)
[![Build Status via Travis CI](https://travis-ci.org/hapijs/pez.svg?branch=master)](https://travis-ci.org/hapijs/pez)
![Dependencies](http://img.shields.io/david/hapijs/pez.svg)

Multipart parser.

Lead Maintainer - [Colin Ihrig](https://github.com/cjihrig)
