var bar = require('./bar');

module.exports = {bar: bar};