module.exports = {
  f: {
    g: function () {
      return 'g'
    }
  },
  h: function () {
    return 'h'
  }
};