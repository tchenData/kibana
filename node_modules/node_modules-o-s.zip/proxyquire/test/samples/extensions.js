module.exports = {
    fs: require('fs') 
  , fn: require('fn')
  , '/fs.json': require('/fs.json')
  , '/fn.node': require('/fn.node')
};
