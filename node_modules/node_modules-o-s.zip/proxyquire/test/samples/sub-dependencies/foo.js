var baz = require('./baz');
var bar = require('./bar');

module.exports = {
  baz: baz,
  bar: bar
};
