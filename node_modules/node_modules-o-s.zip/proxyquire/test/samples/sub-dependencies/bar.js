var baz = require('./baz');

module.exports = {
  baz: baz
};
