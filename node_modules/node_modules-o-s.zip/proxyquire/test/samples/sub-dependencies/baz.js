module.exports = {
  testexport: 'test'
};
