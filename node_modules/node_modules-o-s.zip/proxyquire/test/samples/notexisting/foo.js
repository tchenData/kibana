var bar = require('/not/existing/bar.json');

module.exports = {
  config: bar.config
};
