# 1.2.1

* Fixes an issue where rem measurements were being quoted alongside the font
  family name.

# 1.2.0

* Adds support for a configuration object; some optimisations can be disabled.

# 1.1.1

* Fixes an issue where 'Din' was being picked up by the logic as a numeric
  value, causing the full font name to be incorrectly rearranged.
* Plugin guidelines compatibility.

# 1.1.0

* Now uses the PostCSS `4.1` plugin API.

# 1.0.2

* Adds a JSHint config, code tidied up.

# 1.0.1

* Bug fix; now properly identifies unit-less values.

# 1.0.0

* Initial release.
