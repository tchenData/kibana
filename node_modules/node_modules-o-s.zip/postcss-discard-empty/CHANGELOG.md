# 1.1.2

* Increased performance by iterating the AST in a single pass.
  (thanks @andyjansson)

# 1.1.1

* Tweaks for compatibility with the plugin guidelines.

# 1.1.0

* Now uses the PostCSS `4.1` plugin API.

# 1.0.0

* Initial release.
