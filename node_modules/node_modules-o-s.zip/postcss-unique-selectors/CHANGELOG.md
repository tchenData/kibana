# 1.0.1

* Removed an unnecessary dependency on css-list.

# 1.0.0

* Initial release.
