#vise

Treat multiple buffers as one.

[![Build Status](https://secure.travis-ci.org/hapijs/vise.png)](http://travis-ci.org/hapijs/vise)

Lead Maintainer - [Anna Luisa Patiño West](https://github.com/aisapatino)
