# util-extend

The Node object extending function that Node uses for Node!

## Usage

```js
var extend = require('util-extend');
function functionThatTakesOptions(options) {
  var options = extend(defaults, options);
  // now any unset options are set to the defaults.
}
```
