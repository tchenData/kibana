1.0.1 / 2016-01-17
==================

  * perf: enable strict mode

1.0.0 / 2015-03-01
==================

  * Add option to only add new descriptors
  * Add simple argument validation
  * Add jsdoc to source file

0.0.2 / 2013-12-14
==================

  * Move repository to `component` organization

0.0.1 / 2013-10-29
==================

  * Initial release
