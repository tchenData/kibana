Changelog
=========

-	v3.0.1 update dev Dependencies
-	v3.0.0 [Bugfix](https://github.com/karanlyons/murmurHash3.js/pull/2) this version is equal to fork [Version 2.1.6](https://github.com/karanlyons/murmurHash3.js/blob/c1778f75792abef7bdd74bc85d2d4e1a3d25cfe9/murmurHash3.js)
-	v2.1.6 removed testing for Node.js v0.8
-	v2.1.5 udate devDependencies
-	v2.1.4 add to bower.io; last version running with Node.js v0.8.x
-	v2.1.3 update devDependencies
-	v2.1.2 initial version; fork from https://github.com/karanlyons/murmurHash3.js ([Version 2.1.2](https://github.com/karanlyons/murmurHash3.js/blob/03bac51479581ab53e3b224ac474f4df69a89029/murmurHash3.js)\)
