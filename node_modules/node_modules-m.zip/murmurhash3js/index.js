module.exports = require('./lib/murmurHash3js');
