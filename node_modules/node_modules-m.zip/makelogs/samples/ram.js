var gb = 1024 * 1024 * 1024;

module.exports = [
  2 * gb,
  3 * gb,
  4 * gb,
  5 * gb,
  6 * gb,
  7 * gb,
  8 * gb,
  9 * gb,
  10 * gb,
  11 * gb,
  12 * gb,
  13 * gb,
  14 * gb,
  15 * gb,
  16 * gb,
  17 * gb,
  18 * gb,
  19 * gb,
  20 * gb,
  30 * gb,
];