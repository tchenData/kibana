marked-text-renderer
====================

Renderer for marked outputting plain text that can easily be fed to a search indexer/tokenizer/...
