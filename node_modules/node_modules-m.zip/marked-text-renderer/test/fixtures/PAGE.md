# Python basics

Python is a nice language, you can add stuff. Bla bla bla.

Lets jump into an exercise :

---

It's dead simple, `c` must be the sum of `a` and `b`

```py
a = 1
b = 2
```

```py
a = 1
b = 2
c = a + b
```

```py
assert(c, 3)
```

---

Some more nice content ....

[Cool stuff](http://gitbook.io)

[Link to another Markdown file](./xyz/file.md)
