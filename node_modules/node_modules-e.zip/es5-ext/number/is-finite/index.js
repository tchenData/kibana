'use strict';

module.exports = require('./is-implemented')()
	? Number.isFinite
	: require('./shim');
