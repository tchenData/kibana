'use strict';

module.exports = 2.220446049250313e-16;
