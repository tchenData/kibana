// 2016 March 8
// https://github.com/bevry/editions
module.exports = require('editions').requirePackage(__dirname, require)
