'use strict';

exports.http = require('./http.js');
exports.https = require('./https.js');
