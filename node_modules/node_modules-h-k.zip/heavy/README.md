#heavy

Measure process load.

[![Build Status](https://secure.travis-ci.org/hapijs/heavy.png)](http://travis-ci.org/hapijs/heavy)

Lead Maintainer - [Kevin Decker](https://github.com/kpdecker)
