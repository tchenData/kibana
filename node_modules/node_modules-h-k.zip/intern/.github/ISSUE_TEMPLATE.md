<!--
Hi, and thanks for your interest! To keep this issue tracker focused on development, we ask that you only open issues for bugs and feature requests. If you're reporting a bug, please describe the problem in detail and provide enough information for it to be reproduced (OS, browser/Node version, test case).

If you have a question about how to use Intern, the best places to get help are Stack Overflow and IRC. See https://theintern.github.io/intern/#getting-help for more information.
-->
