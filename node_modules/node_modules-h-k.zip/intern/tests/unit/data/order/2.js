(function () {
	/*jshint evil:true */
	var global = (new Function('return this')());
	global.order = global.order || [];
	global.order.push(2);
})();
