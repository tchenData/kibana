"use strict";

module.exports = function isObject(x) {
	return typeof x === "object" && x !== null;
};
