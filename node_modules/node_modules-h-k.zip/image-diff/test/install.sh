sudo apt-get install graphicsmagick -y
