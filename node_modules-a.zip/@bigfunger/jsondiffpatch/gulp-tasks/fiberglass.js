var path = require('path');
var gulp = require('gulp');
var fiberglass = require('fiberglass');

fiberglass.tasks(gulp, path.join(__dirname, '..')).register(
  ''
);
