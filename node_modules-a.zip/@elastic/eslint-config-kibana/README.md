# eslint-config-kibana

The eslint config used by the kibana team
