
import React, {
  Component,
} from 'react';

export default class NotFoundView extends Component {

  constructor(props) {
    super(props);
  }

  render() {
    return (
      <div>
        <h1>Page not found.</h1>
      </div>
    );
  }

}
