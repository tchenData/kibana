# test-subj-selector

Convert a string from test subject syntax to css selectors.
