# babel-cli

Babel CLI

For more information please look at [babel](https://github.com/babel/babel).
