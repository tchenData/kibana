module.exports = require("babel-core/polyfill");
