module.exports = require("babel-core/register-without-polyfill");
