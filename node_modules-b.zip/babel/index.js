module.exports = require("babel-core");
