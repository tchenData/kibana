/* eslint no-unused-vars:0 */
export default function ({ Plugin, types: t }) {
  return new Plugin("NAME", {
    visitor: {
      // your visitor methods go here
    }
  });
}
