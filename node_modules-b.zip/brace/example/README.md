# brace example

Please investigate the following to understand how to use brace:
 - the page itself containing `<div>` place holders for the editors: **index.html**
 - styles to position the editors: **index.css**
 - the browserify build script: **build.js**
 - the editor initialization scripts: **coffee-editor.js**, **javascript-editor.js**, **json-editor.js**,
   **lua-editor.js** and **css-editor.js** (currently not used)
 - **coffee-editor.js** and **javascript-editor.js** also demonstrate Ace's Vim keybinding feature
